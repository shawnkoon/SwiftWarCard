//
//  ViewController.swift
//  War Card
//
//  Created by Shawn Son on 2/21/16.
//  Copyright © 2016 shawnkoon. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstCardImageView: UIImageView!
    @IBOutlet weak var secondCardImageView: UIImageView!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var backGroundImageView: UIImageView!
    @IBOutlet weak var score1: UILabel!
    @IBOutlet weak var score2: UILabel!
    @IBOutlet weak var drawImage: UIImageView!
    
    var curScore1:Int = 0;
    var curScore2:Int = 0;
    
    var cards:[String] = ["card2","card3","card4","card5","card6","card7","card8","card9","card10", "jack","queen","king","ace"];
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //self.playButton.setTitle("Deal", forState: UIControlState.Normal);
        curScore1 = 0;
        curScore2 = 0;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func playButtonTapped(sender: UIButton){
        
        //Create randome numbers.
        let rand1 = Int(arc4random_uniform(13));
        let rand2 = Int(arc4random_uniform(13));
        
        //Set the image of the cards.
        self.firstCardImageView.image = UIImage(named: self.cards[rand1]);
        self.secondCardImageView.image = UIImage(named: self.cards[rand2]);
        
        
        //Compare two cards now.
        if(rand1 > rand2)
        {
            //If card #1 win.
            curScore1++;
            
            score1.text = String(format: "%i", curScore1);
        }
        else if(rand1 < rand2)
        {
            //If card #2 win.
            curScore2++;
            
            score2.text = String(format: "%i", curScore2);
        }
        else
        {
            //If they tie.
            
        }
    }

}

